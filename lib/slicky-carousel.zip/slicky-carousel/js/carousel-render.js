jQuery(document).ready(function($){
    $('.slicky-carousel-wrapper').slick(
        slickySettings.all
    );
});
