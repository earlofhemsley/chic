<?php 
    echo <<< EOT
        <div>
            <a href="$href">
                <img src="{$image_src[0]}" />
            </a>
        </div>
EOT;
?>
